package com.ibm.messmanagement.exception;

public class MessException extends Exception
{
	public MessException (String str)
	{
		super(str);
	}

}


