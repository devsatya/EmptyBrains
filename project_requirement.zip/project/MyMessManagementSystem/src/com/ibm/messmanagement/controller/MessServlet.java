package com.ibm.messmanagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.messmanagement.dto.MessMenuDetails;
import com.ibm.messmanagement.service.MessServiceImplementation;
import com.ibm.messmanagement.service.MessServiceInterface;

public class MessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    ServletContext ctx=getServletContext();
		String path=request.getServletPath();
		System.out.println(path);
		if(path.equals("insert.do"))
		{
			int Id=Integer.parseInt(request.getParameter("id"));
			String Day=request.getParameter("day");
			String Breakfast=request.getParameter("breakfastitems");
			String Lunch=request.getParameter("lunchitems");
			String Dinner=request.getParameter("dinneritems");
			double price=Double.parseDouble(request.getParameter("price"));
			MessMenuDetails menu=new MessMenuDetails(Id,Day,Breakfast,Lunch,Dinner,price);
			MessServiceInterface mess=new MessServiceImplementation();
			
			mess.createMess(menu);
			System.out.println("addition done till now");
		}
		
				
	
		
		
		
		
		
	}

}
