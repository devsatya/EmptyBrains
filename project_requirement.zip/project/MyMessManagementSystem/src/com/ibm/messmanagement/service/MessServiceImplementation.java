package com.ibm.messmanagement.service;


import com.ibm.messmanagement.dao.MessSystemImplementation;
import com.ibm.messmanagement.dao.MessSystemInterface;
import com.ibm.messmanagement.dto.MessMenuDetails;
import com.ibm.messmanagement.exception.MessException;

public class MessServiceImplementation implements MessServiceInterface {

	@Override
	public boolean createMess(MessMenuDetails menu)throws MessException {
		if(menu.getBreakfastItems().length()<5)
			try {
				throw new MessException("user name should be more than 5 characters");
			} catch (MessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else
		{
			System.out.println("in service");
			 MessSystemInterface mess=new MessSystemImplementation();
		     return	mess.createMess(menu);
		}
		return false;

	
       //return null;
}
}