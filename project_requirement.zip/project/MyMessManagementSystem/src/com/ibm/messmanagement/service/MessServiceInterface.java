package com.ibm.messmanagement.service;

import com.ibm.messmanagement.dto.MessMenuDetails;
import com.ibm.messmanagement.exception.MessException;


public interface MessServiceInterface {
	public boolean createMess(MessMenuDetails menu)throws MessException;
}
