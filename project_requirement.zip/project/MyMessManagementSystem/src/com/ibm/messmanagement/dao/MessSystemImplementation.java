package com.ibm.messmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.ibm.messmanagement.dto.MessMenuDetails;
import com.ibm.messmanagement.exception.MessException;
public class MessSystemImplementation implements MessSystemInterface{
	public boolean createMess(MessMenuDetails menu) throws MessException
	{
		try
	{
		Connection con=ConnectionFactory.getConnection();
		String query="insert into FOOD_MENU values(?,?,?,?,?,?)";
		PreparedStatement psmt=con.prepareStatement(query);
		psmt.setInt(1, menu.getId());
		psmt.setString(2, menu.getDay());
		psmt.setString(3, menu.getBreakfastItems());
		psmt.setString(4, menu.getLunchItems());
		psmt.setString(5, menu.getDinnerItems());
		psmt.setDouble(6, menu.getPrice());
		if(psmt.executeUpdate()>0)
		{
			System.out.println("record inserted");
			return true;
		}
		else{
			System.out.println("user not created");
		return false;
		}
	}
	catch(Exception e)
	{
		throw new MessException("database error");//not show actual exception in place of it throw your own exception to user
	}
		//return false;
}

	@Override
	public void delete(MessMenuDetails menu) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
}
