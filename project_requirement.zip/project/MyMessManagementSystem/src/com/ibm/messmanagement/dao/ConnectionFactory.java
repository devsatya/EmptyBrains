package com.ibm.messmanagement.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionFactory {
public static Connection getConnection()throws Exception
{
	
	try
	
	{
		Properties prop=new Properties();
		String path="D:/javaservlet/MyMessManagementSystem\\resources\\jdbc\\jdbc.properties";
		FileInputStream fis=new FileInputStream(path);
		prop.load(fis);
		
		
		 String driver=prop.getProperty("driver");
		    
		
		
		String username=prop.getProperty("username");
		String password=prop.getProperty("password");
		String url=prop.getProperty("url");
		
	//Class.forName("oracle.jdbc.driver.OracleDriver");//step1	;//load .class file dynamically in program
	//String url="jdbc:oracle:thin:@localhost:1521:xe";
	//String uname="system";
	//String pwd="system";
	Class.forName(driver);
	Connection con=DriverManager.getConnection(url,username,password);	
	return con;
	}
	
	catch(Exception e)
    {
    System.out.println(e);
    }
    return null;
}
}
