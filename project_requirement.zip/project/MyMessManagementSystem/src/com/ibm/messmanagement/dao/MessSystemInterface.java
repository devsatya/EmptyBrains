package com.ibm.messmanagement.dao;

import com.ibm.messmanagement.dto.MessMenuDetails;
import com.ibm.messmanagement.exception.MessException;

public interface MessSystemInterface {
 public boolean createMess(MessMenuDetails menu)throws MessException;
 public void delete	(MessMenuDetails menu);
}
