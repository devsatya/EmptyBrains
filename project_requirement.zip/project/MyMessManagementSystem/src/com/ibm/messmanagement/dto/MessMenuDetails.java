package com.ibm.messmanagement.dto;

public class MessMenuDetails {

	private  int id;
	private String day;
	private String breakfastItems;
	private String lunchItems;
	private String dinnerItems;
	private double price;
	
	public MessMenuDetails(int id,String day,String breakfastItems,String lunchItems,String dinnerItems,double price)
	{
		setId(id);
		setDay(day);
		setBreakfastItems(breakfastItems);
		setLunchItems(lunchItems);
		setDinnerItems(dinnerItems);
		setPrice(price);
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getBreakfastItems() {
		return breakfastItems;
	}
	public void setBreakfastItems(String breakfastItems) {
		this.breakfastItems = breakfastItems;
	}
	public String getLunchItems() {
		return lunchItems;
	}
	public void setLunchItems(String lunchItems) {
		this.lunchItems = lunchItems;
	}
	public String getDinnerItems() {
		return dinnerItems;
	}
	public void setDinnerItems(String dinnerItems) {
		this.dinnerItems = dinnerItems;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
