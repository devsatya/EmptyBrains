package com.multiplex.pl;

import java.util.*;
import com.multiplex.dao.*;
import com.multiplex.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MultiplexController {

//@SuppressWarnings("unused")

	@Autowired
	private MultiplexDao dao;

	@RequestMapping(value="/isignup")
	public ModelAndView welcome()
	{
		ModelAndView model=new ModelAndView("test");
		//String msg="this is a test";
		//model.addObject(msg);
		
		return model;
		
	}
	
	
	
	@RequestMapping(value="/login")
	public String login(@RequestParam("pnum") String userName ,@RequestParam("password") String pwd,ModelMap model) {  

		Customer cust=new Customer();
		cust.setUserName(userName);
		cust.setPassword(pwd);
		
		boolean status=dao.userLogin(cust);
		if(status)
		{
				//model.addAttribute("cust", status);
			return "home";
		}
		return "error";
	}


	@RequestMapping(value="/signup")
	public String signUp(@RequestParam("userid") String id,@RequestParam("username") String uname,@RequestParam("password") String pwd ,@RequestParam("pnum") String mobileNo,@RequestParam("gender") String gender,@RequestParam("email") String email, ModelMap model)
	{
		Customer cust=new Customer();
		cust.setUserId(id);
		cust.setUserName(uname);
		cust.setPassword(pwd);
		cust.setMobileNo(mobileNo);
		cust.setMail(email);
		cust.setGender(gender);
		
		int i=dao.userRegister(cust);
		if(i==1)
			return "login";
		else 
			return "error";

	}

/*	@RequestMapping(value="/dsignup")
	public String doctorSignUp(@RequestParam("doctorid") String dId,@RequestParam("doctorname") String dname,@RequestParam("password") String pwd ,@RequestParam("pnum") String pnum,@RequestParam("hcode") String hcode,@RequestParam("specialization") String specialization ,@RequestParam("hname") String hname, ModelMap model)
	{
		Doctor doctor=new Doctor();
		doctor.setDoctorid(dId);
		doctor.setDoctorname(dname);
		doctor.setMobileno(pnum);
		doctor.setHname(hname);
		doctor.setHospitalcode(hcode);
		doctor.setPassword(pwd);
		doctor.setSpecialization(specialization);
		int i=dao.doctorSignUp(doctor);
		if(i==1)
			return "success";
		else 
			return "error";

	}

	@RequestMapping(value="/search")
	public ModelAndView search(@RequestParam("location") String location) {  
		Location loc= new Location();
		loc.setLoc(location);
		List<Location> hlist=dao.getHospitals(loc);
		ModelAndView model = new ModelAndView("nearHospitals");
		
		model.addObject("hlist", hlist);
		return model;
	}

	@RequestMapping(value="/searchdoctor")
	public ModelAndView searchDoctor(@RequestParam("id") String hcode) {  
		Doctor doctor= new Doctor();
		doctor.setHospitalcode(hcode);
		List<Doctor> dlist=dao.getDoctors(doctor);
		ModelAndView model = new ModelAndView("doctorList");
		model.addObject("dlist", dlist);
		return model;
	}*/
}
