package com.multiplex.pl;

import com.multiplex.dao.MultiplexDaoInter;
import com.multiplex.dto.Customer;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;  

@Repository
public class MultiplexDao implements MultiplexDaoInter{

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
		this.jdbcTemplate = jdbcTemplate;  
	}  

	@Override
	public boolean userLogin(Customer cust) {
		String username=cust.getUserName();
		String sql="select userid, MOBILENO from Users where username = (?)";
		System.out.println("he");
		Customer pwd = (Customer)jdbcTemplate.queryForObject(sql, new Object[] {username}, new UserMapper());
		
		if(pwd.getPassword().equals(cust.getPassword())){
		System.out.println(pwd.getUserId());
			return true;
		
		}
		
		else
		{	
			return false;

		}


	}
	
	private static class UserMapper implements RowMapper<Customer>{
		public Customer mapRow(ResultSet rslt, int arg1) throws SQLException {
			Customer cust = new Customer();
			cust.setMobileNo(rslt.getString(2));
			cust.setUserId(rslt.getString(1));
			
			return cust;
		}

	}
	

	@Override
	public int userRegister(Customer cust) {
		String sql = "INSERT INTO user_login VALUES(?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,cust.getUserId(),cust.getUserName(), cust.getPassword(),cust.getMobileNo(),cust.getMail(),cust.getGender());
	}

}
