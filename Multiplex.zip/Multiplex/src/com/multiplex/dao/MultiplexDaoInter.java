package com.multiplex.dao;

import com.multiplex.dto.Customer;

public interface MultiplexDaoInter {

	public boolean userLogin(Customer cust);
	public int userRegister(Customer cust);
	
}
