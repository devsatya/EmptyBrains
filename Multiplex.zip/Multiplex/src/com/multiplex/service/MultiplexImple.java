package com.multiplex.service;

import com.multiplex.dto.*;
import com.multiplex.dao.*;

public class MultiplexImple implements MultiplexInter{

	@Override
	public boolean userLogin(Customer cust) {
		// TODO Auto-generated method stub
		MultiplexDaoInter mul=new MultiplexDao();
		return mul.userLogin(cust);
	}

	@Override
	public int Register(Customer cust) {
		// TODO Auto-generated method stub
		MultiplexDaoInter mul=new MultiplexDao();
		return mul.userRegister(cust);

	}

}
