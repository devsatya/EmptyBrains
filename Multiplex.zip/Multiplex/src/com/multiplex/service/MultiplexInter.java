package com.multiplex.service;

import com.multiplex.dto.Customer;

public interface MultiplexInter {

	public boolean userLogin(Customer cust);
	public int Register(Customer cust);
	
}
